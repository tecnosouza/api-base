
-- TABLE: SequelizeMeta

COPY "SequelizeMeta" FROM stdin;
20250714223038-create-table-persons.js
20250714223039-create-table-person-notes.js
20250714223040-create-table-phones.js
20250714223041-create-table-phone-notes.js
20250714223042-create-table-emails.js
20250714223043-create-table-email-notes.js
20250714223044-create-table-addresses.js
20250714223045-create-table-access-levels.js
20250714223046-create-table-access.js
20250714223047-create-table-settings.js
20250714223048-create-table-categories.js
20250714223049-create-table-products.js
20250829214025-create-error-logs.js
\.


-- TABLE: email_notes


-- TABLE: persons

COPY "persons" FROM stdin;
1	true	Henrique	Souza	Fri Sep 25 1992 21:00:00 GMT-0300 (Horário Padrão de Brasília)	123456789	12345678901	rick	$2b$10$zGoSuviJC/P8hMYUfNb/C.gAJGnVaEEHiDLhIsB/ly8I3dNrmLcIG	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
\.


-- TABLE: person_notes


-- TABLE: phones

COPY "phones" FROM stdin;
1	1	55	11	964464779	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
\.


-- TABLE: phone_notes


-- TABLE: emails


-- TABLE: addresses

COPY "addresses" FROM stdin;
1	1	true	13227130	Rua campo grande	134	Casa 1	Recanto quarto centenário	Várzea Paulista	São Paulo	-23.6027226	-46.7881327	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
\.


-- TABLE: access_levels

COPY "access_levels" FROM stdin;
1	Acesso total	[{"id":"dashboard","label":"dashboard","to":"/","c":"1","r":"1","u":"1","d":"1","e":[],"level":0},{"id":"warehouses","label":"warehouses","to":"/register/warehouses","c":"1","r":"1","u":"1","d":"1","e":[],"level":1},{"id":"clients","label":"clients","to":"/register/clients","c":"1","r":"1","u":"1","d":"1","e":{},"level":1},{"id":"suppliers","label":"suppliers","to":"/register/suppliers","c":"1","r":"1","u":"1","d":"1","e":[],"level":1},{"id":"storages","label":"storages","to":"/register/products/storages","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"categories","label":"categories","to":"/register/products/categories","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"colors","label":"colors","to":"/register/products/colors","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"sizes","label":"sizes","to":"/register/products/sizes","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"memories","label":"memories","to":"/register/products/memories","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"products","label":"products","to":"/register/products/product","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"users","label":"users","to":"/register/users","c":"1","r":"1","u":"1","d":"1","e":{"ap":"1"},"level":2},{"id":"sectors","label":"sectors","to":"/register/sectors","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"payments-conditions","label":"payments-conditions","to":"/register/payments-conditions","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"operations","label":"operations","to":"/register/operations","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"stock","label":"stock","to":"/stock","c":"1","r":"1","u":"1","d":"1","e":[],"level":0},{"id":"sales","label":"sales","to":"/sales","c":"1","r":"1","u":"1","d":"1","e":[],"level":0},{"id":"categories-cash-flow","label":"categories-cash-flow","to":"/cash-flow/categories-cash-movement","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"movements-cash-flow","label":"movements-cash-flow","to":"/cash-flow/cash-movement","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"report-pendencies","label":"report-pendencies","to":"/reports/pendencies","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"report-stock","label":"report-stock","to":"/reports/products-in-stock","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"configurations","label":"configurations","to":"/configurations","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"}]	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N	true
2	Sem acesso	[{"label": "dashboard","level": 0,"c": "0","r": "0","u": "1","d": "0","e": []},{"label": "warehouses","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "clients","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "suppliers","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "products","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "system_users","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "access_level","level": 2,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "users","level": 2,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "sectors","level": 2,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "stock",        "level": 0,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "sales","level": 0,"c": "1","r": "1","u": "1","d": "1","e": []}]	false	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N	true
3	Acesso limitado	[{"label": "dashboard","level": 0,"c": "0","r": "0","u": "1","d": "0","e": []},{"label": "warehouses","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "clients","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "suppliers","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "products","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "system_users","level": 1,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "access_level","level": 2,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "users","level": 2,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "sectors","level": 2,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "stock",        "level": 0,"c": "1","r": "1","u": "1","d": "1","e": []},{"label": "sales","level": 0,"c": "1","r": "1","u": "1","d": "1","e": []}]	false	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N	true
\.


-- TABLE: accesses

COPY "accesses" FROM stdin;
1	1	[{"id":"dashboard","label":"dashboard","to":"/","c":"1","r":"1","u":"1","d":"1","e":[],"level":0},{"id":"warehouses","label":"warehouses","to":"/register/warehouses","c":"1","r":"1","u":"1","d":"1","e":[],"level":1},{"id":"clients","label":"clients","to":"/register/clients","c":"1","r":"1","u":"1","d":"1","e":{},"level":1},{"id":"suppliers","label":"suppliers","to":"/register/suppliers","c":"1","r":"1","u":"1","d":"1","e":[],"level":1},{"id":"storages","label":"storages","to":"/register/products/storages","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"categories","label":"categories","to":"/register/products/categories","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"colors","label":"colors","to":"/register/products/colors","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"sizes","label":"sizes","to":"/register/products/sizes","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"memories","label":"memories","to":"/register/products/memories","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"products","label":"products","to":"/register/products/product","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"users","label":"users","to":"/register/users","c":"1","r":"1","u":"1","d":"1","e":{"ap":"1"},"level":2},{"id":"sectors","label":"sectors","to":"/register/sectors","c":"1","r":"1","u":"1","d":"1","e":[],"level":2},{"id":"payments-conditions","label":"payments-conditions","to":"/register/payments-conditions","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"operations","label":"operations","to":"/register/operations","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"stock","label":"stock","to":"/stock","c":"1","r":"1","u":"1","d":"1","e":[],"level":0},{"id":"sales","label":"sales","to":"/sales","c":"1","r":"1","u":"1","d":"1","e":[],"level":0},{"id":"categories-cash-flow","label":"categories-cash-flow","to":"/cash-flow/categories-cash-movement","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"movements-cash-flow","label":"movements-cash-flow","to":"/cash-flow/cash-movement","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"report-pendencies","label":"report-pendencies","to":"/reports/pendencies","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"report-best-clients","label":"report-best-clients","to":"/reports/best-clients","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"report-most-profitable-products","label":"report-most-profitable-products","to":"/reports/most-profitable-products","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"report-stock","label":"report-stock","to":"/reports/products-in-stock","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"report-stock","label":"report-stock","to":"/reports/sales-products","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"},{"id":"report-comission","label":"report-comission","to":"/reports/commissions","c":"1","r":"1","u":"1","d":"1","e":[]},{"id":"configurations","label":"configurations","to":"/configurations","c":"1","r":"1","u":"1","d":"1","e":[],"level":"0"}]	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
\.


-- TABLE: settings

COPY "settings" FROM stdin;
1	1	14	0	1	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
\.


-- TABLE: categories

COPY "categories" FROM stdin;
1	Aditivos + adesivos	Aditivos + adesivos	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
2	Argamassas poliméricas para impermeabilização	Argamassas poliméricas para impermeabilização	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
3	Selantes	Selantes	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
4	Acrílicos (manta líquida) e masquite	Acrílicos e masquite	(Manta líquida)	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
5	Membrana auto adesivas alumínio	Membrana auto adesivas alumínio	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
6	Mantas asfálticas	Mantas asfálticas	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
7	Primer	Primer	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
8	Recuperação estrutural e impermeabilização	Recuperação estrutural e impermeabilização	Nossos Produtos	true	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	Tue Oct 07 2025 12:30:11 GMT-0300 (Horário Padrão de Brasília)	\N
\.


-- TABLE: products


-- TABLE: error_logs

